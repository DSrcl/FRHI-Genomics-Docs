﻿using System;
using System.Collections.Generic;
using Hl7.Fhir.Introspection;
using Hl7.Fhir.Validation;
using System.Linq;
using System.Runtime.Serialization;

/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

*/

//
// Generated on Tue, Jul 28, 2015 17:31-0400 for FHIR v0.5.0
//
namespace Hl7.Fhir.Model
{
    /// <summary>
    /// Sequence of a macromolecule
    /// </summary>
    [FhirType("Sequence", IsResource=true)]
    [DataContract]
    public partial class Sequence : Hl7.Fhir.Model.DomainResource, System.ComponentModel.INotifyPropertyChanged
    {
        [NotMapped]
        public override ResourceType ResourceType { get { return ResourceType.Sequence; } }
        [NotMapped]
        public override string TypeName { get { return "Sequence"; } }
        
        /// <summary>
        /// Type of a sequence
        /// </summary>
        [FhirEnumeration("SequenceType")]
        public enum SequenceType
        {
            /// <summary>
            /// DNA Sequence
            /// </summary>
            [EnumLiteral("dna")]
            Dna,
            /// <summary>
            /// RNA Sequence
            /// </summary>
            [EnumLiteral("rna")]
            Rna,
            /// <summary>
            /// Amino acid sequence (protein)
            /// </summary>
            [EnumLiteral("aa")]
            Aa,
        }
        
        /// <summary>
        /// Direction of a sequence
        /// </summary>
        [FhirEnumeration("StrandDirection")]
        public enum StrandDirection
        {
            /// <summary>
            /// A forward strand i.e. a sequence in 5-3 direction
            /// </summary>
            [EnumLiteral("forward")]
            Forward,
            /// <summary>
            /// A reverse strand i.e. a sequence in 3-5 direction
            /// </summary>
            [EnumLiteral("reverse")]
            Reverse,
        }
        
        /// <summary>
        /// Type of the sample used to determine a seauence
        /// </summary>
        [FhirEnumeration("SampleType")]
        public enum SampleType
        {
            /// <summary>
            /// Germline
            /// </summary>
            [EnumLiteral("germline")]
            Germline,
            /// <summary>
            /// Somatic
            /// </summary>
            [EnumLiteral("somatic")]
            Somatic,
            /// <summary>
            /// Prenatal
            /// </summary>
            [EnumLiteral("prenatal")]
            Prenatal,
        }
        
        /// <summary>
        /// Chromosome of the sequence
        /// </summary>
        [FhirElement("chromosome", Order=90)]
        [Cardinality(Min=1,Max=1)]
        [DataMember]
        public Hl7.Fhir.Model.FhirString ChromosomeElement
        {
            get { return _ChromosomeElement; }
            set { _ChromosomeElement = value; OnPropertyChanged("ChromosomeElement"); }
        }
        
        private Hl7.Fhir.Model.FhirString _ChromosomeElement;
        
        /// <summary>
        /// Chromosome of the sequence
        /// </summary>
        /// <remarks>This uses the native .NET datatype, rather than the FHIR equivalent</remarks>
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public string Chromosome
        {
            get { return ChromosomeElement != null ? ChromosomeElement.Value : null; }
            set
            {
                if(value == null)
                  ChromosomeElement = null; 
                else
                  ChromosomeElement = new Hl7.Fhir.Model.FhirString(value);
                OnPropertyChanged("Chromosome");
            }
        }
        
        /// <summary>
        /// Start position of the sequence
        /// </summary>
        [FhirElement("startPosition", Order=100)]
        [Cardinality(Min=1,Max=1)]
        [DataMember]
        public Hl7.Fhir.Model.Integer StartPositionElement
        {
            get { return _StartPositionElement; }
            set { _StartPositionElement = value; OnPropertyChanged("StartPositionElement"); }
        }
        
        private Hl7.Fhir.Model.Integer _StartPositionElement;
        
        /// <summary>
        /// Start position of the sequence
        /// </summary>
        /// <remarks>This uses the native .NET datatype, rather than the FHIR equivalent</remarks>
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public int? StartPosition
        {
            get { return StartPositionElement != null ? StartPositionElement.Value : null; }
            set
            {
                if(value == null)
                  StartPositionElement = null; 
                else
                  StartPositionElement = new Hl7.Fhir.Model.Integer(value);
                OnPropertyChanged("StartPosition");
            }
        }
        
        /// <summary>
        /// End position of the sequence
        /// </summary>
        [FhirElement("endPosition", Order=110)]
        [Cardinality(Min=1,Max=1)]
        [DataMember]
        public Hl7.Fhir.Model.Integer EndPositionElement
        {
            get { return _EndPositionElement; }
            set { _EndPositionElement = value; OnPropertyChanged("EndPositionElement"); }
        }
        
        private Hl7.Fhir.Model.Integer _EndPositionElement;
        
        /// <summary>
        /// End position of the sequence
        /// </summary>
        /// <remarks>This uses the native .NET datatype, rather than the FHIR equivalent</remarks>
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public int? EndPosition
        {
            get { return EndPositionElement != null ? EndPositionElement.Value : null; }
            set
            {
                if(value == null)
                  EndPositionElement = null; 
                else
                  EndPositionElement = new Hl7.Fhir.Model.Integer(value);
                OnPropertyChanged("EndPosition");
            }
        }
        
        /// <summary>
        /// forward | reverse
        /// </summary>
        [FhirElement("direction", Order=120)]
        [DataMember]
        public Code<Hl7.Fhir.Model.Sequence.StrandDirection> DirectionElement
        {
            get { return _DirectionElement; }
            set { _DirectionElement = value; OnPropertyChanged("DirectionElement"); }
        }
        
        private Code<Hl7.Fhir.Model.Sequence.StrandDirection> _DirectionElement;
        
        /// <summary>
        /// forward | reverse
        /// </summary>
        /// <remarks>This uses the native .NET datatype, rather than the FHIR equivalent</remarks>
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public Hl7.Fhir.Model.Sequence.StrandDirection? Direction
        {
            get { return DirectionElement != null ? DirectionElement.Value : null; }
            set
            {
                if(value == null)
                  DirectionElement = null; 
                else
                  DirectionElement = new Code<Hl7.Fhir.Model.Sequence.StrandDirection>(value);
                OnPropertyChanged("Direction");
            }
        }
        
        /// <summary>
        /// CIGAR string for the sequence
        /// </summary>
        [FhirElement("cigar", Order=130)]
        [DataMember]
        public Hl7.Fhir.Model.FhirString CigarElement
        {
            get { return _CigarElement; }
            set { _CigarElement = value; OnPropertyChanged("CigarElement"); }
        }
        
        private Hl7.Fhir.Model.FhirString _CigarElement;
        
        /// <summary>
        /// CIGAR string for the sequence
        /// </summary>
        /// <remarks>This uses the native .NET datatype, rather than the FHIR equivalent</remarks>
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public string Cigar
        {
            get { return CigarElement != null ? CigarElement.Value : null; }
            set
            {
                if(value == null)
                  CigarElement = null; 
                else
                  CigarElement = new Hl7.Fhir.Model.FhirString(value);
                OnPropertyChanged("Cigar");
            }
        }
        
        /// <summary>
        /// germline | somatic | prenatal
        /// </summary>
        [FhirElement("sample", Order=140)]
        [DataMember]
        public Code<Hl7.Fhir.Model.Sequence.SampleType> SampleElement
        {
            get { return _SampleElement; }
            set { _SampleElement = value; OnPropertyChanged("SampleElement"); }
        }
        
        private Code<Hl7.Fhir.Model.Sequence.SampleType> _SampleElement;
        
        /// <summary>
        /// germline | somatic | prenatal
        /// </summary>
        /// <remarks>This uses the native .NET datatype, rather than the FHIR equivalent</remarks>
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public Hl7.Fhir.Model.Sequence.SampleType? Sample
        {
            get { return SampleElement != null ? SampleElement.Value : null; }
            set
            {
                if(value == null)
                  SampleElement = null; 
                else
                  SampleElement = new Code<Hl7.Fhir.Model.Sequence.SampleType>(value);
                OnPropertyChanged("Sample");
            }
        }
        
        /// <summary>
        /// Lab where the sequence is determined
        /// </summary>
        [FhirElement("lab", Order=150)]
        [References("DiagnosticOrder")]
        [DataMember]
        public Hl7.Fhir.Model.ResourceReference Lab
        {
            get { return _Lab; }
            set { _Lab = value; OnPropertyChanged("Lab"); }
        }
        
        private Hl7.Fhir.Model.ResourceReference _Lab;
        
        /// <summary>
        /// Whom the sequence is determined for
        /// </summary>
        [FhirElement("patient", Order=160)]
        [References("Patient")]
        [Cardinality(Min=1,Max=1)]
        [DataMember]
        public Hl7.Fhir.Model.ResourceReference Patient
        {
            get { return _Patient; }
            set { _Patient = value; OnPropertyChanged("Patient"); }
        }
        
        private Hl7.Fhir.Model.ResourceReference _Patient;
        
        /// <summary>
        /// Species of the organism whom the sequence belongs to
        /// </summary>
        [FhirElement("species", Order=170)]
        [Cardinality(Min=1,Max=1)]
        [DataMember]
        public Hl7.Fhir.Model.CodeableConcept Species
        {
            get { return _Species; }
            set { _Species = value; OnPropertyChanged("Species"); }
        }
        
        private Hl7.Fhir.Model.CodeableConcept _Species;
        
        /// <summary>
        /// Quantity of molecule encoded by the sequence presenting in the sample
        /// </summary>
        [FhirElement("quantity", Order=180)]
        [DataMember]
        public Hl7.Fhir.Model.Quantity Quantity
        {
            get { return _Quantity; }
            set { _Quantity = value; OnPropertyChanged("Quantity"); }
        }
        
        private Hl7.Fhir.Model.Quantity _Quantity;
        
        /// <summary>
        /// Genome assembly
        /// </summary>
        [FhirElement("genomeBuild", Order=190)]
        [DataMember]
        public Hl7.Fhir.Model.FhirString GenomeBuildElement
        {
            get { return _GenomeBuildElement; }
            set { _GenomeBuildElement = value; OnPropertyChanged("GenomeBuildElement"); }
        }
        
        private Hl7.Fhir.Model.FhirString _GenomeBuildElement;
        
        /// <summary>
        /// Genome assembly
        /// </summary>
        /// <remarks>This uses the native .NET datatype, rather than the FHIR equivalent</remarks>
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public string GenomeBuild
        {
            get { return GenomeBuildElement != null ? GenomeBuildElement.Value : null; }
            set
            {
                if(value == null)
                  GenomeBuildElement = null; 
                else
                  GenomeBuildElement = new Hl7.Fhir.Model.FhirString(value);
                OnPropertyChanged("GenomeBuild");
            }
        }
        
        /// <summary>
        /// dna | rna | aa
        /// </summary>
        [FhirElement("type", Order=200)]
        [Cardinality(Min=1,Max=1)]
        [DataMember]
        public Code<Hl7.Fhir.Model.Sequence.SequenceType> TypeElement
        {
            get { return _TypeElement; }
            set { _TypeElement = value; OnPropertyChanged("TypeElement"); }
        }
        
        private Code<Hl7.Fhir.Model.Sequence.SequenceType> _TypeElement;
        
        /// <summary>
        /// dna | rna | aa
        /// </summary>
        /// <remarks>This uses the native .NET datatype, rather than the FHIR equivalent</remarks>
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public Hl7.Fhir.Model.Sequence.SequenceType? Type
        {
            get { return TypeElement != null ? TypeElement.Value : null; }
            set
            {
                if(value == null)
                  TypeElement = null; 
                else
                  TypeElement = new Code<Hl7.Fhir.Model.Sequence.SequenceType>(value);
                OnPropertyChanged("Type");
            }
        }
        
        /// <summary>
        /// Reference bases of the sequence
        /// </summary>
        [FhirElement("referenceSequence", Order=210)]
        [DataMember]
        public Hl7.Fhir.Model.FhirString ReferenceSequenceElement
        {
            get { return _ReferenceSequenceElement; }
            set { _ReferenceSequenceElement = value; OnPropertyChanged("ReferenceSequenceElement"); }
        }
        
        private Hl7.Fhir.Model.FhirString _ReferenceSequenceElement;
        
        /// <summary>
        /// Reference bases of the sequence
        /// </summary>
        /// <remarks>This uses the native .NET datatype, rather than the FHIR equivalent</remarks>
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public string ReferenceSequence
        {
            get { return ReferenceSequenceElement != null ? ReferenceSequenceElement.Value : null; }
            set
            {
                if(value == null)
                  ReferenceSequenceElement = null; 
                else
                  ReferenceSequenceElement = new Hl7.Fhir.Model.FhirString(value);
                OnPropertyChanged("ReferenceSequence");
            }
        }
        
        /// <summary>
        /// Observed bases of the sequence
        /// </summary>
        [FhirElement("observedSequence", Order=220)]
        [Cardinality(Min=1,Max=1)]
        [DataMember]
        public Hl7.Fhir.Model.FhirString ObservedSequenceElement
        {
            get { return _ObservedSequenceElement; }
            set { _ObservedSequenceElement = value; OnPropertyChanged("ObservedSequenceElement"); }
        }
        
        private Hl7.Fhir.Model.FhirString _ObservedSequenceElement;
        
        /// <summary>
        /// Observed bases of the sequence
        /// </summary>
        /// <remarks>This uses the native .NET datatype, rather than the FHIR equivalent</remarks>
        [NotMapped]
        [IgnoreDataMemberAttribute]
        public string ObservedSequence
        {
            get { return ObservedSequenceElement != null ? ObservedSequenceElement.Value : null; }
            set
            {
                if(value == null)
                  ObservedSequenceElement = null; 
                else
                  ObservedSequenceElement = new Hl7.Fhir.Model.FhirString(value);
                OnPropertyChanged("ObservedSequence");
            }
        }
        
        /// <summary>
        /// Name of the sequence. I.e.  rs6313
        /// </summary>
        [FhirElement("name", Order=230)]
        [Cardinality(Min=0,Max=-1)]
        [DataMember]
        public List<Hl7.Fhir.Model.CodeableConcept> Name
        {
            get { if(_Name==null) _Name = new List<Hl7.Fhir.Model.CodeableConcept>(); return _Name; }
            set { _Name = value; OnPropertyChanged("Name"); }
        }
        
        private List<Hl7.Fhir.Model.CodeableConcept> _Name;
        
        public override IDeepCopyable CopyTo(IDeepCopyable other)
        {
            var dest = other as Sequence;
            
            if (dest != null)
            {
                base.CopyTo(dest);
                if(ChromosomeElement != null) dest.ChromosomeElement = (Hl7.Fhir.Model.FhirString)ChromosomeElement.DeepCopy();
                if(StartPositionElement != null) dest.StartPositionElement = (Hl7.Fhir.Model.Integer)StartPositionElement.DeepCopy();
                if(EndPositionElement != null) dest.EndPositionElement = (Hl7.Fhir.Model.Integer)EndPositionElement.DeepCopy();
                if(DirectionElement != null) dest.DirectionElement = (Code<Hl7.Fhir.Model.Sequence.StrandDirection>)DirectionElement.DeepCopy();
                if(CigarElement != null) dest.CigarElement = (Hl7.Fhir.Model.FhirString)CigarElement.DeepCopy();
                if(SampleElement != null) dest.SampleElement = (Code<Hl7.Fhir.Model.Sequence.SampleType>)SampleElement.DeepCopy();
                if(Lab != null) dest.Lab = (Hl7.Fhir.Model.ResourceReference)Lab.DeepCopy();
                if(Patient != null) dest.Patient = (Hl7.Fhir.Model.ResourceReference)Patient.DeepCopy();
                if(Species != null) dest.Species = (Hl7.Fhir.Model.CodeableConcept)Species.DeepCopy();
                if(Quantity != null) dest.Quantity = (Hl7.Fhir.Model.Quantity)Quantity.DeepCopy();
                if(GenomeBuildElement != null) dest.GenomeBuildElement = (Hl7.Fhir.Model.FhirString)GenomeBuildElement.DeepCopy();
                if(TypeElement != null) dest.TypeElement = (Code<Hl7.Fhir.Model.Sequence.SequenceType>)TypeElement.DeepCopy();
                if(ReferenceSequenceElement != null) dest.ReferenceSequenceElement = (Hl7.Fhir.Model.FhirString)ReferenceSequenceElement.DeepCopy();
                if(ObservedSequenceElement != null) dest.ObservedSequenceElement = (Hl7.Fhir.Model.FhirString)ObservedSequenceElement.DeepCopy();
                if(Name != null) dest.Name = new List<Hl7.Fhir.Model.CodeableConcept>(Name.DeepCopy());
                return dest;
            }
            else
            	throw new ArgumentException("Can only copy to an object of the same type", "other");
        }
        
        public override IDeepCopyable DeepCopy()
        {
            return CopyTo(new Sequence());
        }
        
        public override bool Matches(IDeepComparable other)
        {
            var otherT = other as Sequence;
            if(otherT == null) return false;
            
            if(!base.Matches(otherT)) return false;
            if( !DeepComparable.Matches(ChromosomeElement, otherT.ChromosomeElement)) return false;
            if( !DeepComparable.Matches(StartPositionElement, otherT.StartPositionElement)) return false;
            if( !DeepComparable.Matches(EndPositionElement, otherT.EndPositionElement)) return false;
            if( !DeepComparable.Matches(DirectionElement, otherT.DirectionElement)) return false;
            if( !DeepComparable.Matches(CigarElement, otherT.CigarElement)) return false;
            if( !DeepComparable.Matches(SampleElement, otherT.SampleElement)) return false;
            if( !DeepComparable.Matches(Lab, otherT.Lab)) return false;
            if( !DeepComparable.Matches(Patient, otherT.Patient)) return false;
            if( !DeepComparable.Matches(Species, otherT.Species)) return false;
            if( !DeepComparable.Matches(Quantity, otherT.Quantity)) return false;
            if( !DeepComparable.Matches(GenomeBuildElement, otherT.GenomeBuildElement)) return false;
            if( !DeepComparable.Matches(TypeElement, otherT.TypeElement)) return false;
            if( !DeepComparable.Matches(ReferenceSequenceElement, otherT.ReferenceSequenceElement)) return false;
            if( !DeepComparable.Matches(ObservedSequenceElement, otherT.ObservedSequenceElement)) return false;
            if( !DeepComparable.Matches(Name, otherT.Name)) return false;
            
            return true;
        }
        
        public override bool IsExactly(IDeepComparable other)
        {
            var otherT = other as Sequence;
            if(otherT == null) return false;
            
            if(!base.IsExactly(otherT)) return false;
            if( !DeepComparable.IsExactly(ChromosomeElement, otherT.ChromosomeElement)) return false;
            if( !DeepComparable.IsExactly(StartPositionElement, otherT.StartPositionElement)) return false;
            if( !DeepComparable.IsExactly(EndPositionElement, otherT.EndPositionElement)) return false;
            if( !DeepComparable.IsExactly(DirectionElement, otherT.DirectionElement)) return false;
            if( !DeepComparable.IsExactly(CigarElement, otherT.CigarElement)) return false;
            if( !DeepComparable.IsExactly(SampleElement, otherT.SampleElement)) return false;
            if( !DeepComparable.IsExactly(Lab, otherT.Lab)) return false;
            if( !DeepComparable.IsExactly(Patient, otherT.Patient)) return false;
            if( !DeepComparable.IsExactly(Species, otherT.Species)) return false;
            if( !DeepComparable.IsExactly(Quantity, otherT.Quantity)) return false;
            if( !DeepComparable.IsExactly(GenomeBuildElement, otherT.GenomeBuildElement)) return false;
            if( !DeepComparable.IsExactly(TypeElement, otherT.TypeElement)) return false;
            if( !DeepComparable.IsExactly(ReferenceSequenceElement, otherT.ReferenceSequenceElement)) return false;
            if( !DeepComparable.IsExactly(ObservedSequenceElement, otherT.ObservedSequenceElement)) return false;
            if( !DeepComparable.IsExactly(Name, otherT.Name)) return false;
            
            return true;
        }
        
    }
    
}
