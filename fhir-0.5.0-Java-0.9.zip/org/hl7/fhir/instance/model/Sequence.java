package org.hl7.fhir.instance.model;

/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  
*/

// Generated on Tue, Jul 28, 2015 17:31-0400 for FHIR v0.5.0

import java.util.*;

import org.hl7.fhir.utilities.Utilities;
import org.hl7.fhir.instance.model.annotations.ResourceDef;
import org.hl7.fhir.instance.model.annotations.SearchParamDefinition;
import org.hl7.fhir.instance.model.annotations.Child;
import org.hl7.fhir.instance.model.annotations.Description;
import org.hl7.fhir.instance.model.annotations.Block;
import org.hl7.fhir.instance.model.api.*;
/**
 * This resource records information about sequence of a moleculde. E.g. a DNA sequence.
 */
@ResourceDef(name="Sequence", profile="http://hl7.org/fhir/Profile/Sequence")
public class Sequence extends DomainResource {

    public enum StrandDirection {
        /**
         * A forward strand i.e. a sequence in 5-3 direction
         */
        FORWARD, 
        /**
         * A reverse strand i.e. a sequence in 3-5 direction
         */
        REVERSE, 
        /**
         * added to help the parsers
         */
        NULL;
        public static StrandDirection fromCode(String codeString) throws Exception {
            if (codeString == null || "".equals(codeString))
                return null;
        if ("forward".equals(codeString))
          return FORWARD;
        if ("reverse".equals(codeString))
          return REVERSE;
        throw new Exception("Unknown StrandDirection code '"+codeString+"'");
        }
        public String toCode() {
          switch (this) {
            case FORWARD: return "forward";
            case REVERSE: return "reverse";
            default: return "?";
          }
        }
        public String getSystem() {
          switch (this) {
            case FORWARD: return "http://hl7.org/fhir/strand-direction";
            case REVERSE: return "http://hl7.org/fhir/strand-direction";
            default: return "?";
          }
        }
        public String getDefinition() {
          switch (this) {
            case FORWARD: return "A forward strand i.e. a sequence in 5-3 direction";
            case REVERSE: return "A reverse strand i.e. a sequence in 3-5 direction";
            default: return "?";
          }
        }
        public String getDisplay() {
          switch (this) {
            case FORWARD: return "Forward";
            case REVERSE: return "Reverse";
            default: return "?";
          }
        }
    }

  public static class StrandDirectionEnumFactory implements EnumFactory<StrandDirection> {
    public StrandDirection fromCode(String codeString) throws IllegalArgumentException {
      if (codeString == null || "".equals(codeString))
            if (codeString == null || "".equals(codeString))
                return null;
        if ("forward".equals(codeString))
          return StrandDirection.FORWARD;
        if ("reverse".equals(codeString))
          return StrandDirection.REVERSE;
        throw new IllegalArgumentException("Unknown StrandDirection code '"+codeString+"'");
        }
    public String toCode(StrandDirection code) {
      if (code == StrandDirection.FORWARD)
        return "forward";
      if (code == StrandDirection.REVERSE)
        return "reverse";
      return "?";
      }
    }

    public enum SampleType {
        /**
         * Germline
         */
        GERMLINE, 
        /**
         * Somatic
         */
        SOMATIC, 
        /**
         * Prenatal
         */
        PRENATAL, 
        /**
         * added to help the parsers
         */
        NULL;
        public static SampleType fromCode(String codeString) throws Exception {
            if (codeString == null || "".equals(codeString))
                return null;
        if ("germline".equals(codeString))
          return GERMLINE;
        if ("somatic".equals(codeString))
          return SOMATIC;
        if ("prenatal".equals(codeString))
          return PRENATAL;
        throw new Exception("Unknown SampleType code '"+codeString+"'");
        }
        public String toCode() {
          switch (this) {
            case GERMLINE: return "germline";
            case SOMATIC: return "somatic";
            case PRENATAL: return "prenatal";
            default: return "?";
          }
        }
        public String getSystem() {
          switch (this) {
            case GERMLINE: return "http://hl7.org/fhir/sample-type";
            case SOMATIC: return "http://hl7.org/fhir/sample-type";
            case PRENATAL: return "http://hl7.org/fhir/sample-type";
            default: return "?";
          }
        }
        public String getDefinition() {
          switch (this) {
            case GERMLINE: return "Germline";
            case SOMATIC: return "Somatic";
            case PRENATAL: return "Prenatal";
            default: return "?";
          }
        }
        public String getDisplay() {
          switch (this) {
            case GERMLINE: return "Germline";
            case SOMATIC: return "Somatic";
            case PRENATAL: return "Prenatal";
            default: return "?";
          }
        }
    }

  public static class SampleTypeEnumFactory implements EnumFactory<SampleType> {
    public SampleType fromCode(String codeString) throws IllegalArgumentException {
      if (codeString == null || "".equals(codeString))
            if (codeString == null || "".equals(codeString))
                return null;
        if ("germline".equals(codeString))
          return SampleType.GERMLINE;
        if ("somatic".equals(codeString))
          return SampleType.SOMATIC;
        if ("prenatal".equals(codeString))
          return SampleType.PRENATAL;
        throw new IllegalArgumentException("Unknown SampleType code '"+codeString+"'");
        }
    public String toCode(SampleType code) {
      if (code == SampleType.GERMLINE)
        return "germline";
      if (code == SampleType.SOMATIC)
        return "somatic";
      if (code == SampleType.PRENATAL)
        return "prenatal";
      return "?";
      }
    }

    public enum SequenceType {
        /**
         * DNA Sequence
         */
        DNA, 
        /**
         * RNA Sequence
         */
        RNA, 
        /**
         * Amino acid sequence (protein)
         */
        AA, 
        /**
         * added to help the parsers
         */
        NULL;
        public static SequenceType fromCode(String codeString) throws Exception {
            if (codeString == null || "".equals(codeString))
                return null;
        if ("dna".equals(codeString))
          return DNA;
        if ("rna".equals(codeString))
          return RNA;
        if ("aa".equals(codeString))
          return AA;
        throw new Exception("Unknown SequenceType code '"+codeString+"'");
        }
        public String toCode() {
          switch (this) {
            case DNA: return "dna";
            case RNA: return "rna";
            case AA: return "aa";
            default: return "?";
          }
        }
        public String getSystem() {
          switch (this) {
            case DNA: return "http://hl7.org/fhir/sequence-type";
            case RNA: return "http://hl7.org/fhir/sequence-type";
            case AA: return "http://hl7.org/fhir/sequence-type";
            default: return "?";
          }
        }
        public String getDefinition() {
          switch (this) {
            case DNA: return "DNA Sequence";
            case RNA: return "RNA Sequence";
            case AA: return "Amino acid sequence (protein)";
            default: return "?";
          }
        }
        public String getDisplay() {
          switch (this) {
            case DNA: return "Dna";
            case RNA: return "Rna";
            case AA: return "Aa";
            default: return "?";
          }
        }
    }

  public static class SequenceTypeEnumFactory implements EnumFactory<SequenceType> {
    public SequenceType fromCode(String codeString) throws IllegalArgumentException {
      if (codeString == null || "".equals(codeString))
            if (codeString == null || "".equals(codeString))
                return null;
        if ("dna".equals(codeString))
          return SequenceType.DNA;
        if ("rna".equals(codeString))
          return SequenceType.RNA;
        if ("aa".equals(codeString))
          return SequenceType.AA;
        throw new IllegalArgumentException("Unknown SequenceType code '"+codeString+"'");
        }
    public String toCode(SequenceType code) {
      if (code == SequenceType.DNA)
        return "dna";
      if (code == SequenceType.RNA)
        return "rna";
      if (code == SequenceType.AA)
        return "aa";
      return "?";
      }
    }

    /**
     * Chromosome of the sequence. E.g. "1" for chromosome 1. Note that value of `chromosome` is not limited to a human's chromosomes, as the sequence can be from other species such as Tuberculosis.
     */
    @Child(name = "chromosome", type = {StringType.class}, order=0, min=1, max=1)
    @Description(shortDefinition="Chromosome of the sequence", formalDefinition="Chromosome of the sequence. E.g. '1' for chromosome 1. Note that value of `chromosome` is not limited to a human's chromosomes, as the sequence can be from other species such as Tuberculosis." )
    protected StringType chromosome;

    /**
     * 0-based location start position (inclusive) of the sequence.
     */
    @Child(name = "startPosition", type = {IntegerType.class}, order=1, min=1, max=1)
    @Description(shortDefinition="Start position of the sequence", formalDefinition="0-based location start position (inclusive) of the sequence." )
    protected IntegerType startPosition;

    /**
     * 0-based end location (exclusive) of the sequence.
     */
    @Child(name = "endPosition", type = {IntegerType.class}, order=2, min=1, max=1)
    @Description(shortDefinition="End position of the sequence", formalDefinition="0-based end location (exclusive) of the sequence." )
    protected IntegerType endPosition;

    /**
     * Direction of the strand.  Forward means the sequence is in 5'-3' direction, reverse otherwise.
     */
    @Child(name = "direction", type = {CodeType.class}, order=3, min=0, max=1)
    @Description(shortDefinition="forward | reverse", formalDefinition="Direction of the strand.  Forward means the sequence is in 5'-3' direction, reverse otherwise." )
    protected Enumeration<StrandDirection> direction;

    /**
     * Extended CIGAR string for aligning the sequence with reference bases. See detailed documentation [here](http://support.illumina.com/help/SequencingAnalysisWorkflow/Content/Vault/Informatics/Sequencing_Analysis/CASAVA/swSEQ_mCA_ExtendedCIGARFormat.htm).
     */
    @Child(name = "cigar", type = {StringType.class}, order=4, min=0, max=1)
    @Description(shortDefinition="CIGAR string for the sequence", formalDefinition="Extended CIGAR string for aligning the sequence with reference bases. See detailed documentation [here](http://support.illumina.com/help/SequencingAnalysisWorkflow/Content/Vault/Informatics/Sequencing_Analysis/CASAVA/swSEQ_mCA_ExtendedCIGARFormat.htm)." )
    protected StringType cigar;

    /**
     * Tissue sample from which molecules encoded by the sequence are extracted.
     */
    @Child(name = "sample", type = {CodeType.class}, order=5, min=0, max=1)
    @Description(shortDefinition="germline | somatic | prenatal", formalDefinition="Tissue sample from which molecules encoded by the sequence are extracted." )
    protected Enumeration<SampleType> sample;

    /**
     * Lab where the sequence is determined.
     */
    @Child(name = "lab", type = {DiagnosticOrder.class}, order=6, min=0, max=1)
    @Description(shortDefinition="Lab where the sequence is determined", formalDefinition="Lab where the sequence is determined." )
    protected Reference lab;

    /**
     * The actual object that is the target of the reference (Lab where the sequence is determined.)
     */
    protected DiagnosticOrder labTarget;

    /**
     * Whom the sequence is determined for. In a prenatal sequencing test, the patient being referenced is the birthgiver.
     */
    @Child(name = "patient", type = {Patient.class}, order=7, min=1, max=1)
    @Description(shortDefinition="Whom the sequence is determined for", formalDefinition="Whom the sequence is determined for. In a prenatal sequencing test, the patient being referenced is the birthgiver." )
    protected Reference patient;

    /**
     * The actual object that is the target of the reference (Whom the sequence is determined for. In a prenatal sequencing test, the patient being referenced is the birthgiver.)
     */
    protected Patient patientTarget;

    /**
     * Species of the organism whom the sequence belongs to. The species is not limited to Homo sapiens. E.g. the sequence can be a DNA sequence of a bacteria.
     */
    @Child(name = "species", type = {CodeableConcept.class}, order=8, min=1, max=1)
    @Description(shortDefinition="Species of the organism whom the sequence belongs to", formalDefinition="Species of the organism whom the sequence belongs to. The species is not limited to Homo sapiens. E.g. the sequence can be a DNA sequence of a bacteria." )
    protected CodeableConcept species;

    /**
     * Quantity of molecule encoded by the sequence presenting in the sample.
     */
    @Child(name = "quantity", type = {Quantity.class}, order=9, min=0, max=1)
    @Description(shortDefinition="Quantity of molecule encoded by the sequence presenting in the sample", formalDefinition="Quantity of molecule encoded by the sequence presenting in the sample." )
    protected Quantity quantity;

    /**
     * Genome assembly used to align the sequence.
     */
    @Child(name = "genomeBuild", type = {StringType.class}, order=10, min=0, max=1)
    @Description(shortDefinition="Genome assembly", formalDefinition="Genome assembly used to align the sequence." )
    protected StringType genomeBuild;

    /**
     * Type of the sequence. E.g. DNA.
     */
    @Child(name = "type", type = {CodeType.class}, order=11, min=1, max=1)
    @Description(shortDefinition="dna | rna | aa", formalDefinition="Type of the sequence. E.g. DNA." )
    protected Enumeration<SequenceType> type;

    /**
     * Reference bases of the sequence.
     */
    @Child(name = "referenceSequence", type = {StringType.class}, order=12, min=0, max=1)
    @Description(shortDefinition="Reference bases of the sequence", formalDefinition="Reference bases of the sequence." )
    protected StringType referenceSequence;

    /**
     * Observed bases of the sequence.
     */
    @Child(name = "observedSequence", type = {StringType.class}, order=13, min=1, max=1)
    @Description(shortDefinition="Observed bases of the sequence", formalDefinition="Observed bases of the sequence." )
    protected StringType observedSequence;

    /**
     * Alterantive name of the sequence -- e.g. gene covered by the sequence, exome region in which the sequence is located, rsid of the sequence if it's a SNP, etc.
     */
    @Child(name = "name", type = {CodeableConcept.class}, order=14, min=0, max=Child.MAX_UNLIMITED)
    @Description(shortDefinition="Name of the sequence. I.e.  rs6313", formalDefinition="Alterantive name of the sequence -- e.g. gene covered by the sequence, exome region in which the sequence is located, rsid of the sequence if it's a SNP, etc." )
    protected List<CodeableConcept> name;

    private static final long serialVersionUID = -376631653L;

  /*
   * Constructor
   */
    public Sequence() {
      super();
    }

  /*
   * Constructor
   */
    public Sequence(StringType chromosome, IntegerType startPosition, IntegerType endPosition, Reference patient, CodeableConcept species, Enumeration<SequenceType> type, StringType observedSequence) {
      super();
      this.chromosome = chromosome;
      this.startPosition = startPosition;
      this.endPosition = endPosition;
      this.patient = patient;
      this.species = species;
      this.type = type;
      this.observedSequence = observedSequence;
    }

    /**
     * @return {@link #chromosome} (Chromosome of the sequence. E.g. "1" for chromosome 1. Note that value of `chromosome` is not limited to a human's chromosomes, as the sequence can be from other species such as Tuberculosis.). This is the underlying object with id, value and extensions. The accessor "getChromosome" gives direct access to the value
     */
    public StringType getChromosomeElement() { 
      if (this.chromosome == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.chromosome");
        else if (Configuration.doAutoCreate())
          this.chromosome = new StringType(); // bb
      return this.chromosome;
    }

    public boolean hasChromosomeElement() { 
      return this.chromosome != null && !this.chromosome.isEmpty();
    }

    public boolean hasChromosome() { 
      return this.chromosome != null && !this.chromosome.isEmpty();
    }

    /**
     * @param value {@link #chromosome} (Chromosome of the sequence. E.g. "1" for chromosome 1. Note that value of `chromosome` is not limited to a human's chromosomes, as the sequence can be from other species such as Tuberculosis.). This is the underlying object with id, value and extensions. The accessor "getChromosome" gives direct access to the value
     */
    public Sequence setChromosomeElement(StringType value) { 
      this.chromosome = value;
      return this;
    }

    /**
     * @return Chromosome of the sequence. E.g. "1" for chromosome 1. Note that value of `chromosome` is not limited to a human's chromosomes, as the sequence can be from other species such as Tuberculosis.
     */
    public String getChromosome() { 
      return this.chromosome == null ? null : this.chromosome.getValue();
    }

    /**
     * @param value Chromosome of the sequence. E.g. "1" for chromosome 1. Note that value of `chromosome` is not limited to a human's chromosomes, as the sequence can be from other species such as Tuberculosis.
     */
    public Sequence setChromosome(String value) { 
        if (this.chromosome == null)
          this.chromosome = new StringType();
        this.chromosome.setValue(value);
      return this;
    }

    /**
     * @return {@link #startPosition} (0-based location start position (inclusive) of the sequence.). This is the underlying object with id, value and extensions. The accessor "getStartPosition" gives direct access to the value
     */
    public IntegerType getStartPositionElement() { 
      if (this.startPosition == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.startPosition");
        else if (Configuration.doAutoCreate())
          this.startPosition = new IntegerType(); // bb
      return this.startPosition;
    }

    public boolean hasStartPositionElement() { 
      return this.startPosition != null && !this.startPosition.isEmpty();
    }

    public boolean hasStartPosition() { 
      return this.startPosition != null && !this.startPosition.isEmpty();
    }

    /**
     * @param value {@link #startPosition} (0-based location start position (inclusive) of the sequence.). This is the underlying object with id, value and extensions. The accessor "getStartPosition" gives direct access to the value
     */
    public Sequence setStartPositionElement(IntegerType value) { 
      this.startPosition = value;
      return this;
    }

    /**
     * @return 0-based location start position (inclusive) of the sequence.
     */
    public int getStartPosition() { 
      return this.startPosition == null || this.startPosition.isEmpty() ? 0 : this.startPosition.getValue();
    }

    /**
     * @param value 0-based location start position (inclusive) of the sequence.
     */
    public Sequence setStartPosition(int value) { 
        if (this.startPosition == null)
          this.startPosition = new IntegerType();
        this.startPosition.setValue(value);
      return this;
    }

    /**
     * @return {@link #endPosition} (0-based end location (exclusive) of the sequence.). This is the underlying object with id, value and extensions. The accessor "getEndPosition" gives direct access to the value
     */
    public IntegerType getEndPositionElement() { 
      if (this.endPosition == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.endPosition");
        else if (Configuration.doAutoCreate())
          this.endPosition = new IntegerType(); // bb
      return this.endPosition;
    }

    public boolean hasEndPositionElement() { 
      return this.endPosition != null && !this.endPosition.isEmpty();
    }

    public boolean hasEndPosition() { 
      return this.endPosition != null && !this.endPosition.isEmpty();
    }

    /**
     * @param value {@link #endPosition} (0-based end location (exclusive) of the sequence.). This is the underlying object with id, value and extensions. The accessor "getEndPosition" gives direct access to the value
     */
    public Sequence setEndPositionElement(IntegerType value) { 
      this.endPosition = value;
      return this;
    }

    /**
     * @return 0-based end location (exclusive) of the sequence.
     */
    public int getEndPosition() { 
      return this.endPosition == null || this.endPosition.isEmpty() ? 0 : this.endPosition.getValue();
    }

    /**
     * @param value 0-based end location (exclusive) of the sequence.
     */
    public Sequence setEndPosition(int value) { 
        if (this.endPosition == null)
          this.endPosition = new IntegerType();
        this.endPosition.setValue(value);
      return this;
    }

    /**
     * @return {@link #direction} (Direction of the strand.  Forward means the sequence is in 5'-3' direction, reverse otherwise.). This is the underlying object with id, value and extensions. The accessor "getDirection" gives direct access to the value
     */
    public Enumeration<StrandDirection> getDirectionElement() { 
      if (this.direction == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.direction");
        else if (Configuration.doAutoCreate())
          this.direction = new Enumeration<StrandDirection>(new StrandDirectionEnumFactory()); // bb
      return this.direction;
    }

    public boolean hasDirectionElement() { 
      return this.direction != null && !this.direction.isEmpty();
    }

    public boolean hasDirection() { 
      return this.direction != null && !this.direction.isEmpty();
    }

    /**
     * @param value {@link #direction} (Direction of the strand.  Forward means the sequence is in 5'-3' direction, reverse otherwise.). This is the underlying object with id, value and extensions. The accessor "getDirection" gives direct access to the value
     */
    public Sequence setDirectionElement(Enumeration<StrandDirection> value) { 
      this.direction = value;
      return this;
    }

    /**
     * @return Direction of the strand.  Forward means the sequence is in 5'-3' direction, reverse otherwise.
     */
    public StrandDirection getDirection() { 
      return this.direction == null ? null : this.direction.getValue();
    }

    /**
     * @param value Direction of the strand.  Forward means the sequence is in 5'-3' direction, reverse otherwise.
     */
    public Sequence setDirection(StrandDirection value) { 
      if (value == null)
        this.direction = null;
      else {
        if (this.direction == null)
          this.direction = new Enumeration<StrandDirection>(new StrandDirectionEnumFactory());
        this.direction.setValue(value);
      }
      return this;
    }

    /**
     * @return {@link #cigar} (Extended CIGAR string for aligning the sequence with reference bases. See detailed documentation [here](http://support.illumina.com/help/SequencingAnalysisWorkflow/Content/Vault/Informatics/Sequencing_Analysis/CASAVA/swSEQ_mCA_ExtendedCIGARFormat.htm).). This is the underlying object with id, value and extensions. The accessor "getCigar" gives direct access to the value
     */
    public StringType getCigarElement() { 
      if (this.cigar == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.cigar");
        else if (Configuration.doAutoCreate())
          this.cigar = new StringType(); // bb
      return this.cigar;
    }

    public boolean hasCigarElement() { 
      return this.cigar != null && !this.cigar.isEmpty();
    }

    public boolean hasCigar() { 
      return this.cigar != null && !this.cigar.isEmpty();
    }

    /**
     * @param value {@link #cigar} (Extended CIGAR string for aligning the sequence with reference bases. See detailed documentation [here](http://support.illumina.com/help/SequencingAnalysisWorkflow/Content/Vault/Informatics/Sequencing_Analysis/CASAVA/swSEQ_mCA_ExtendedCIGARFormat.htm).). This is the underlying object with id, value and extensions. The accessor "getCigar" gives direct access to the value
     */
    public Sequence setCigarElement(StringType value) { 
      this.cigar = value;
      return this;
    }

    /**
     * @return Extended CIGAR string for aligning the sequence with reference bases. See detailed documentation [here](http://support.illumina.com/help/SequencingAnalysisWorkflow/Content/Vault/Informatics/Sequencing_Analysis/CASAVA/swSEQ_mCA_ExtendedCIGARFormat.htm).
     */
    public String getCigar() { 
      return this.cigar == null ? null : this.cigar.getValue();
    }

    /**
     * @param value Extended CIGAR string for aligning the sequence with reference bases. See detailed documentation [here](http://support.illumina.com/help/SequencingAnalysisWorkflow/Content/Vault/Informatics/Sequencing_Analysis/CASAVA/swSEQ_mCA_ExtendedCIGARFormat.htm).
     */
    public Sequence setCigar(String value) { 
      if (Utilities.noString(value))
        this.cigar = null;
      else {
        if (this.cigar == null)
          this.cigar = new StringType();
        this.cigar.setValue(value);
      }
      return this;
    }

    /**
     * @return {@link #sample} (Tissue sample from which molecules encoded by the sequence are extracted.). This is the underlying object with id, value and extensions. The accessor "getSample" gives direct access to the value
     */
    public Enumeration<SampleType> getSampleElement() { 
      if (this.sample == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.sample");
        else if (Configuration.doAutoCreate())
          this.sample = new Enumeration<SampleType>(new SampleTypeEnumFactory()); // bb
      return this.sample;
    }

    public boolean hasSampleElement() { 
      return this.sample != null && !this.sample.isEmpty();
    }

    public boolean hasSample() { 
      return this.sample != null && !this.sample.isEmpty();
    }

    /**
     * @param value {@link #sample} (Tissue sample from which molecules encoded by the sequence are extracted.). This is the underlying object with id, value and extensions. The accessor "getSample" gives direct access to the value
     */
    public Sequence setSampleElement(Enumeration<SampleType> value) { 
      this.sample = value;
      return this;
    }

    /**
     * @return Tissue sample from which molecules encoded by the sequence are extracted.
     */
    public SampleType getSample() { 
      return this.sample == null ? null : this.sample.getValue();
    }

    /**
     * @param value Tissue sample from which molecules encoded by the sequence are extracted.
     */
    public Sequence setSample(SampleType value) { 
      if (value == null)
        this.sample = null;
      else {
        if (this.sample == null)
          this.sample = new Enumeration<SampleType>(new SampleTypeEnumFactory());
        this.sample.setValue(value);
      }
      return this;
    }

    /**
     * @return {@link #lab} (Lab where the sequence is determined.)
     */
    public Reference getLab() { 
      if (this.lab == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.lab");
        else if (Configuration.doAutoCreate())
          this.lab = new Reference(); // cc
      return this.lab;
    }

    public boolean hasLab() { 
      return this.lab != null && !this.lab.isEmpty();
    }

    /**
     * @param value {@link #lab} (Lab where the sequence is determined.)
     */
    public Sequence setLab(Reference value) { 
      this.lab = value;
      return this;
    }

    /**
     * @return {@link #lab} The actual object that is the target of the reference. The reference library doesn't populate this, but you can use it to hold the resource if you resolve it. (Lab where the sequence is determined.)
     */
    public DiagnosticOrder getLabTarget() { 
      if (this.labTarget == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.lab");
        else if (Configuration.doAutoCreate())
          this.labTarget = new DiagnosticOrder(); // aa
      return this.labTarget;
    }

    /**
     * @param value {@link #lab} The actual object that is the target of the reference. The reference library doesn't use these, but you can use it to hold the resource if you resolve it. (Lab where the sequence is determined.)
     */
    public Sequence setLabTarget(DiagnosticOrder value) { 
      this.labTarget = value;
      return this;
    }

    /**
     * @return {@link #patient} (Whom the sequence is determined for. In a prenatal sequencing test, the patient being referenced is the birthgiver.)
     */
    public Reference getPatient() { 
      if (this.patient == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.patient");
        else if (Configuration.doAutoCreate())
          this.patient = new Reference(); // cc
      return this.patient;
    }

    public boolean hasPatient() { 
      return this.patient != null && !this.patient.isEmpty();
    }

    /**
     * @param value {@link #patient} (Whom the sequence is determined for. In a prenatal sequencing test, the patient being referenced is the birthgiver.)
     */
    public Sequence setPatient(Reference value) { 
      this.patient = value;
      return this;
    }

    /**
     * @return {@link #patient} The actual object that is the target of the reference. The reference library doesn't populate this, but you can use it to hold the resource if you resolve it. (Whom the sequence is determined for. In a prenatal sequencing test, the patient being referenced is the birthgiver.)
     */
    public Patient getPatientTarget() { 
      if (this.patientTarget == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.patient");
        else if (Configuration.doAutoCreate())
          this.patientTarget = new Patient(); // aa
      return this.patientTarget;
    }

    /**
     * @param value {@link #patient} The actual object that is the target of the reference. The reference library doesn't use these, but you can use it to hold the resource if you resolve it. (Whom the sequence is determined for. In a prenatal sequencing test, the patient being referenced is the birthgiver.)
     */
    public Sequence setPatientTarget(Patient value) { 
      this.patientTarget = value;
      return this;
    }

    /**
     * @return {@link #species} (Species of the organism whom the sequence belongs to. The species is not limited to Homo sapiens. E.g. the sequence can be a DNA sequence of a bacteria.)
     */
    public CodeableConcept getSpecies() { 
      if (this.species == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.species");
        else if (Configuration.doAutoCreate())
          this.species = new CodeableConcept(); // cc
      return this.species;
    }

    public boolean hasSpecies() { 
      return this.species != null && !this.species.isEmpty();
    }

    /**
     * @param value {@link #species} (Species of the organism whom the sequence belongs to. The species is not limited to Homo sapiens. E.g. the sequence can be a DNA sequence of a bacteria.)
     */
    public Sequence setSpecies(CodeableConcept value) { 
      this.species = value;
      return this;
    }

    /**
     * @return {@link #quantity} (Quantity of molecule encoded by the sequence presenting in the sample.)
     */
    public Quantity getQuantity() { 
      if (this.quantity == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.quantity");
        else if (Configuration.doAutoCreate())
          this.quantity = new Quantity(); // cc
      return this.quantity;
    }

    public boolean hasQuantity() { 
      return this.quantity != null && !this.quantity.isEmpty();
    }

    /**
     * @param value {@link #quantity} (Quantity of molecule encoded by the sequence presenting in the sample.)
     */
    public Sequence setQuantity(Quantity value) { 
      this.quantity = value;
      return this;
    }

    /**
     * @return {@link #genomeBuild} (Genome assembly used to align the sequence.). This is the underlying object with id, value and extensions. The accessor "getGenomeBuild" gives direct access to the value
     */
    public StringType getGenomeBuildElement() { 
      if (this.genomeBuild == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.genomeBuild");
        else if (Configuration.doAutoCreate())
          this.genomeBuild = new StringType(); // bb
      return this.genomeBuild;
    }

    public boolean hasGenomeBuildElement() { 
      return this.genomeBuild != null && !this.genomeBuild.isEmpty();
    }

    public boolean hasGenomeBuild() { 
      return this.genomeBuild != null && !this.genomeBuild.isEmpty();
    }

    /**
     * @param value {@link #genomeBuild} (Genome assembly used to align the sequence.). This is the underlying object with id, value and extensions. The accessor "getGenomeBuild" gives direct access to the value
     */
    public Sequence setGenomeBuildElement(StringType value) { 
      this.genomeBuild = value;
      return this;
    }

    /**
     * @return Genome assembly used to align the sequence.
     */
    public String getGenomeBuild() { 
      return this.genomeBuild == null ? null : this.genomeBuild.getValue();
    }

    /**
     * @param value Genome assembly used to align the sequence.
     */
    public Sequence setGenomeBuild(String value) { 
      if (Utilities.noString(value))
        this.genomeBuild = null;
      else {
        if (this.genomeBuild == null)
          this.genomeBuild = new StringType();
        this.genomeBuild.setValue(value);
      }
      return this;
    }

    /**
     * @return {@link #type} (Type of the sequence. E.g. DNA.). This is the underlying object with id, value and extensions. The accessor "getType" gives direct access to the value
     */
    public Enumeration<SequenceType> getTypeElement() { 
      if (this.type == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.type");
        else if (Configuration.doAutoCreate())
          this.type = new Enumeration<SequenceType>(new SequenceTypeEnumFactory()); // bb
      return this.type;
    }

    public boolean hasTypeElement() { 
      return this.type != null && !this.type.isEmpty();
    }

    public boolean hasType() { 
      return this.type != null && !this.type.isEmpty();
    }

    /**
     * @param value {@link #type} (Type of the sequence. E.g. DNA.). This is the underlying object with id, value and extensions. The accessor "getType" gives direct access to the value
     */
    public Sequence setTypeElement(Enumeration<SequenceType> value) { 
      this.type = value;
      return this;
    }

    /**
     * @return Type of the sequence. E.g. DNA.
     */
    public SequenceType getType() { 
      return this.type == null ? null : this.type.getValue();
    }

    /**
     * @param value Type of the sequence. E.g. DNA.
     */
    public Sequence setType(SequenceType value) { 
        if (this.type == null)
          this.type = new Enumeration<SequenceType>(new SequenceTypeEnumFactory());
        this.type.setValue(value);
      return this;
    }

    /**
     * @return {@link #referenceSequence} (Reference bases of the sequence.). This is the underlying object with id, value and extensions. The accessor "getReferenceSequence" gives direct access to the value
     */
    public StringType getReferenceSequenceElement() { 
      if (this.referenceSequence == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.referenceSequence");
        else if (Configuration.doAutoCreate())
          this.referenceSequence = new StringType(); // bb
      return this.referenceSequence;
    }

    public boolean hasReferenceSequenceElement() { 
      return this.referenceSequence != null && !this.referenceSequence.isEmpty();
    }

    public boolean hasReferenceSequence() { 
      return this.referenceSequence != null && !this.referenceSequence.isEmpty();
    }

    /**
     * @param value {@link #referenceSequence} (Reference bases of the sequence.). This is the underlying object with id, value and extensions. The accessor "getReferenceSequence" gives direct access to the value
     */
    public Sequence setReferenceSequenceElement(StringType value) { 
      this.referenceSequence = value;
      return this;
    }

    /**
     * @return Reference bases of the sequence.
     */
    public String getReferenceSequence() { 
      return this.referenceSequence == null ? null : this.referenceSequence.getValue();
    }

    /**
     * @param value Reference bases of the sequence.
     */
    public Sequence setReferenceSequence(String value) { 
      if (Utilities.noString(value))
        this.referenceSequence = null;
      else {
        if (this.referenceSequence == null)
          this.referenceSequence = new StringType();
        this.referenceSequence.setValue(value);
      }
      return this;
    }

    /**
     * @return {@link #observedSequence} (Observed bases of the sequence.). This is the underlying object with id, value and extensions. The accessor "getObservedSequence" gives direct access to the value
     */
    public StringType getObservedSequenceElement() { 
      if (this.observedSequence == null)
        if (Configuration.errorOnAutoCreate())
          throw new Error("Attempt to auto-create Sequence.observedSequence");
        else if (Configuration.doAutoCreate())
          this.observedSequence = new StringType(); // bb
      return this.observedSequence;
    }

    public boolean hasObservedSequenceElement() { 
      return this.observedSequence != null && !this.observedSequence.isEmpty();
    }

    public boolean hasObservedSequence() { 
      return this.observedSequence != null && !this.observedSequence.isEmpty();
    }

    /**
     * @param value {@link #observedSequence} (Observed bases of the sequence.). This is the underlying object with id, value and extensions. The accessor "getObservedSequence" gives direct access to the value
     */
    public Sequence setObservedSequenceElement(StringType value) { 
      this.observedSequence = value;
      return this;
    }

    /**
     * @return Observed bases of the sequence.
     */
    public String getObservedSequence() { 
      return this.observedSequence == null ? null : this.observedSequence.getValue();
    }

    /**
     * @param value Observed bases of the sequence.
     */
    public Sequence setObservedSequence(String value) { 
        if (this.observedSequence == null)
          this.observedSequence = new StringType();
        this.observedSequence.setValue(value);
      return this;
    }

    /**
     * @return {@link #name} (Alterantive name of the sequence -- e.g. gene covered by the sequence, exome region in which the sequence is located, rsid of the sequence if it's a SNP, etc.)
     */
    public List<CodeableConcept> getName() { 
      if (this.name == null)
        this.name = new ArrayList<CodeableConcept>();
      return this.name;
    }

    public boolean hasName() { 
      if (this.name == null)
        return false;
      for (CodeableConcept item : this.name)
        if (!item.isEmpty())
          return true;
      return false;
    }

    /**
     * @return {@link #name} (Alterantive name of the sequence -- e.g. gene covered by the sequence, exome region in which the sequence is located, rsid of the sequence if it's a SNP, etc.)
     */
    // syntactic sugar
    public CodeableConcept addName() { //3
      CodeableConcept t = new CodeableConcept();
      if (this.name == null)
        this.name = new ArrayList<CodeableConcept>();
      this.name.add(t);
      return t;
    }

    // syntactic sugar
    public Sequence addName(CodeableConcept t) { //3
      if (t == null)
        return this;
      if (this.name == null)
        this.name = new ArrayList<CodeableConcept>();
      this.name.add(t);
      return this;
    }

      protected void listChildren(List<Property> childrenList) {
        super.listChildren(childrenList);
        childrenList.add(new Property("chromosome", "string", "Chromosome of the sequence. E.g. '1' for chromosome 1. Note that value of `chromosome` is not limited to a human's chromosomes, as the sequence can be from other species such as Tuberculosis.", 0, java.lang.Integer.MAX_VALUE, chromosome));
        childrenList.add(new Property("startPosition", "integer", "0-based location start position (inclusive) of the sequence.", 0, java.lang.Integer.MAX_VALUE, startPosition));
        childrenList.add(new Property("endPosition", "integer", "0-based end location (exclusive) of the sequence.", 0, java.lang.Integer.MAX_VALUE, endPosition));
        childrenList.add(new Property("direction", "code", "Direction of the strand.  Forward means the sequence is in 5'-3' direction, reverse otherwise.", 0, java.lang.Integer.MAX_VALUE, direction));
        childrenList.add(new Property("cigar", "string", "Extended CIGAR string for aligning the sequence with reference bases. See detailed documentation [here](http://support.illumina.com/help/SequencingAnalysisWorkflow/Content/Vault/Informatics/Sequencing_Analysis/CASAVA/swSEQ_mCA_ExtendedCIGARFormat.htm).", 0, java.lang.Integer.MAX_VALUE, cigar));
        childrenList.add(new Property("sample", "code", "Tissue sample from which molecules encoded by the sequence are extracted.", 0, java.lang.Integer.MAX_VALUE, sample));
        childrenList.add(new Property("lab", "Reference(DiagnosticOrder)", "Lab where the sequence is determined.", 0, java.lang.Integer.MAX_VALUE, lab));
        childrenList.add(new Property("patient", "Reference(Patient)", "Whom the sequence is determined for. In a prenatal sequencing test, the patient being referenced is the birthgiver.", 0, java.lang.Integer.MAX_VALUE, patient));
        childrenList.add(new Property("species", "CodeableConcept", "Species of the organism whom the sequence belongs to. The species is not limited to Homo sapiens. E.g. the sequence can be a DNA sequence of a bacteria.", 0, java.lang.Integer.MAX_VALUE, species));
        childrenList.add(new Property("quantity", "Quantity", "Quantity of molecule encoded by the sequence presenting in the sample.", 0, java.lang.Integer.MAX_VALUE, quantity));
        childrenList.add(new Property("genomeBuild", "string", "Genome assembly used to align the sequence.", 0, java.lang.Integer.MAX_VALUE, genomeBuild));
        childrenList.add(new Property("type", "code", "Type of the sequence. E.g. DNA.", 0, java.lang.Integer.MAX_VALUE, type));
        childrenList.add(new Property("referenceSequence", "string", "Reference bases of the sequence.", 0, java.lang.Integer.MAX_VALUE, referenceSequence));
        childrenList.add(new Property("observedSequence", "string", "Observed bases of the sequence.", 0, java.lang.Integer.MAX_VALUE, observedSequence));
        childrenList.add(new Property("name", "CodeableConcept", "Alterantive name of the sequence -- e.g. gene covered by the sequence, exome region in which the sequence is located, rsid of the sequence if it's a SNP, etc.", 0, java.lang.Integer.MAX_VALUE, name));
      }

      public Sequence copy() {
        Sequence dst = new Sequence();
        copyValues(dst);
        dst.chromosome = chromosome == null ? null : chromosome.copy();
        dst.startPosition = startPosition == null ? null : startPosition.copy();
        dst.endPosition = endPosition == null ? null : endPosition.copy();
        dst.direction = direction == null ? null : direction.copy();
        dst.cigar = cigar == null ? null : cigar.copy();
        dst.sample = sample == null ? null : sample.copy();
        dst.lab = lab == null ? null : lab.copy();
        dst.patient = patient == null ? null : patient.copy();
        dst.species = species == null ? null : species.copy();
        dst.quantity = quantity == null ? null : quantity.copy();
        dst.genomeBuild = genomeBuild == null ? null : genomeBuild.copy();
        dst.type = type == null ? null : type.copy();
        dst.referenceSequence = referenceSequence == null ? null : referenceSequence.copy();
        dst.observedSequence = observedSequence == null ? null : observedSequence.copy();
        if (name != null) {
          dst.name = new ArrayList<CodeableConcept>();
          for (CodeableConcept i : name)
            dst.name.add(i.copy());
        };
        return dst;
      }

      protected Sequence typedCopy() {
        return copy();
      }

      @Override
      public boolean equalsDeep(Base other) {
        if (!super.equalsDeep(other))
          return false;
        if (!(other instanceof Sequence))
          return false;
        Sequence o = (Sequence) other;
        return compareDeep(chromosome, o.chromosome, true) && compareDeep(startPosition, o.startPosition, true)
           && compareDeep(endPosition, o.endPosition, true) && compareDeep(direction, o.direction, true) && compareDeep(cigar, o.cigar, true)
           && compareDeep(sample, o.sample, true) && compareDeep(lab, o.lab, true) && compareDeep(patient, o.patient, true)
           && compareDeep(species, o.species, true) && compareDeep(quantity, o.quantity, true) && compareDeep(genomeBuild, o.genomeBuild, true)
           && compareDeep(type, o.type, true) && compareDeep(referenceSequence, o.referenceSequence, true)
           && compareDeep(observedSequence, o.observedSequence, true) && compareDeep(name, o.name, true);
      }

      @Override
      public boolean equalsShallow(Base other) {
        if (!super.equalsShallow(other))
          return false;
        if (!(other instanceof Sequence))
          return false;
        Sequence o = (Sequence) other;
        return compareValues(chromosome, o.chromosome, true) && compareValues(startPosition, o.startPosition, true)
           && compareValues(endPosition, o.endPosition, true) && compareValues(direction, o.direction, true) && compareValues(cigar, o.cigar, true)
           && compareValues(sample, o.sample, true) && compareValues(genomeBuild, o.genomeBuild, true) && compareValues(type, o.type, true)
           && compareValues(referenceSequence, o.referenceSequence, true) && compareValues(observedSequence, o.observedSequence, true)
          ;
      }

      public boolean isEmpty() {
        return super.isEmpty() && (chromosome == null || chromosome.isEmpty()) && (startPosition == null || startPosition.isEmpty())
           && (endPosition == null || endPosition.isEmpty()) && (direction == null || direction.isEmpty())
           && (cigar == null || cigar.isEmpty()) && (sample == null || sample.isEmpty()) && (lab == null || lab.isEmpty())
           && (patient == null || patient.isEmpty()) && (species == null || species.isEmpty()) && (quantity == null || quantity.isEmpty())
           && (genomeBuild == null || genomeBuild.isEmpty()) && (type == null || type.isEmpty()) && (referenceSequence == null || referenceSequence.isEmpty())
           && (observedSequence == null || observedSequence.isEmpty()) && (name == null || name.isEmpty())
          ;
      }

  @Override
  public ResourceType getResourceType() {
    return ResourceType.Sequence;
   }

  @SearchParamDefinition(name="coordinate", path="", description="Search for sequences within a genomic region. For example region '1:123-456' can be translated into '1$gte123$lt456'", type="composite" )
  public static final String SP_COORDINATE = "coordinate";
  @SearchParamDefinition(name="species", path="Sequence.species", description="Species of the orgism whom the sequence belong sto", type="token" )
  public static final String SP_SPECIES = "species";
  @SearchParamDefinition(name="patient", path="Sequence.patient", description="Patient to whom the sequence belongs to", type="reference" )
  public static final String SP_PATIENT = "patient";
  @SearchParamDefinition(name="chromosome", path="Sequence.chromosome", description="Chromosome of the sequence", type="string" )
  public static final String SP_CHROMOSOME = "chromosome";
  @SearchParamDefinition(name="start", path="Sequence.startPosition", description="Start position of the sequence", type="number" )
  public static final String SP_START = "start";
  @SearchParamDefinition(name="name", path="Sequence.name", description="Human readable name of the sequence.", type="token" )
  public static final String SP_NAME = "name";
  @SearchParamDefinition(name="end", path="Sequence.endPosition", description="End position of the sequence", type="number" )
  public static final String SP_END = "end";
  @SearchParamDefinition(name="type", path="Sequence.type", description="Type of the sequence", type="token" )
  public static final String SP_TYPE = "type";
  @SearchParamDefinition(name="lab", path="Sequence.lab", description="Lab in which the sequence is determined", type="reference" )
  public static final String SP_LAB = "lab";
  @SearchParamDefinition(name="sample", path="Sequence.sample", description="Type of sample used to determine the sequence", type="token" )
  public static final String SP_SAMPLE = "sample";

}

